#ifndef	__MID_TIMER_H__
#define __MID_TIMER_H__

#include "ti_msp_dl_config.h"


void timer_init(void);

#endif